function data = OmniTrakFileRead_ReadBlock_V1_LSM303_ACC_SETTINGS(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1800
%		LSM303_ACC_SETTINGS

fprintf(1,'Need to finish coding for Block 1800: LSM303_ACC_SETTINGS');