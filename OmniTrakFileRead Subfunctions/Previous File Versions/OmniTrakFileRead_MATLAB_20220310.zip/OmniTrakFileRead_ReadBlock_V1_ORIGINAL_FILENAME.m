function data = OmniTrakFileRead_ReadBlock_V1_ORIGINAL_FILENAME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		40
%		ORIGINAL_FILENAME

fprintf(1,'Need to finish coding for Block 40: ORIGINAL_FILENAME');