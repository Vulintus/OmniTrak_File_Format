function data = OmniTrakFileRead_ReadBlock_V1_MODULE_FW_TIME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	146
%		DEFINITION:		MODULE_FW_TIME
%		DESCRIPTION:	OTMP Module firmware upload time, copied from the macro, written as characters.

fprintf(1,'Need to finish coding for Block 146: MODULE_FW_TIME\n');