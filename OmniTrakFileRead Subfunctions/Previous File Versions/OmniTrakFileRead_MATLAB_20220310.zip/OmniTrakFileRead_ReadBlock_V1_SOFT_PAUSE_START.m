function data = OmniTrakFileRead_ReadBlock_V1_SOFT_PAUSE_START(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2012
%		SOFT_PAUSE_START

fprintf(1,'Need to finish coding for Block 2012: SOFT_PAUSE_START');