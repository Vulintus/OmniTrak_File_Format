function data = OmniTrakFileRead_ReadBlock_V1_FILE_VERSION(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1
%		FILE_VERSION

fprintf(1,'Need to finish coding for Block 1: FILE_VERSION');