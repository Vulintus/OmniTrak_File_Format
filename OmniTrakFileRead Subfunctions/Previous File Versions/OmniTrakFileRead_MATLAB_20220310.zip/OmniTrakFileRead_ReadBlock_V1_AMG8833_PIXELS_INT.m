function data = OmniTrakFileRead_ReadBlock_V1_AMG8833_PIXELS_INT(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1112
%		AMG8833_PIXELS_INT

fprintf(1,'Need to finish coding for Block 1112: AMG8833_PIXELS_INT');