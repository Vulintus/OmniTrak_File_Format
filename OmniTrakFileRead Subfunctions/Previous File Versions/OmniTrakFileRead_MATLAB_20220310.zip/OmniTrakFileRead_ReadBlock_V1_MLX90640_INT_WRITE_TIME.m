function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_INT_WRITE_TIME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1523
%		MLX90640_INT_WRITE_TIME

fprintf(1,'Need to finish coding for Block 1523: MLX90640_INT_WRITE_TIME');