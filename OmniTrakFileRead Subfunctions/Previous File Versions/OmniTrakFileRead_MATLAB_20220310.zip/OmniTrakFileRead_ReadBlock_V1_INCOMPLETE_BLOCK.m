function data = OmniTrakFileRead_ReadBlock_V1_INCOMPLETE_BLOCK(fid,data)

%	OmniTrak File Block Code (OFBC):
%		50
%		INCOMPLETE_BLOCK

fprintf(1,'Need to finish coding for Block 50: INCOMPLETE_BLOCK');