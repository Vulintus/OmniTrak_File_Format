function data = OmniTrakFileRead_ReadBlock_V1_RTC_STRING(fid,data)

%	OmniTrak File Block Code (OFBC):
%		31
%		RTC_STRING

fprintf(1,'Need to finish coding for Block 31: RTC_STRING');