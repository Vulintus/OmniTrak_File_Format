function data = OmniTrakFileRead_ReadBlock_V1_VL53L0X_ENABLED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1006
%		VL53L0X_ENABLED

fprintf(1,'Need to finish coding for Block 1006: VL53L0X_ENABLED');