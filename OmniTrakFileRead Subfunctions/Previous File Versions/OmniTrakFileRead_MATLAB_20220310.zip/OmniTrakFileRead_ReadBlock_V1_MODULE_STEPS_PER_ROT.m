function data = OmniTrakFileRead_ReadBlock_V1_MODULE_STEPS_PER_ROT(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	2723
%		DEFINITION:		MODULE_STEPS_PER_ROT
%		DESCRIPTION:	Steps per rotation on the specified OTMP module.

fprintf(1,'Need to finish coding for Block 2723: MODULE_STEPS_PER_ROT\n');