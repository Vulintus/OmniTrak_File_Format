function data = OmniTrakFileRead_ReadBlock_V1_PELLET_DISPENSE(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2000
%		PELLET_DISPENSE

fprintf(1,'Need to finish coding for Block 2000: PELLET_DISPENSE');