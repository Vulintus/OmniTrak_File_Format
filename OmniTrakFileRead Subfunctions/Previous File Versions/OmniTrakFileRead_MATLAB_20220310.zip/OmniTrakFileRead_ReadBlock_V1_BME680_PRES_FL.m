function data = OmniTrakFileRead_ReadBlock_V1_BME680_PRES_FL(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1212
%		BME680_PRES_FL

fprintf(1,'Need to finish coding for Block 1212: BME680_PRES_FL\n');