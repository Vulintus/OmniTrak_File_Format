function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_ENABLED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1008
%		MLX90640_ENABLED

fprintf(1,'Need to finish coding for Block 1008: MLX90640_ENABLED');