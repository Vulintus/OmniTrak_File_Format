function data = OmniTrakFileRead_ReadBlock_V1_POSITION_MOVE_XY(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2023
%		POSITION_MOVE_XY

fprintf(1,'Need to finish coding for Block 2023: POSITION_MOVE_XY');