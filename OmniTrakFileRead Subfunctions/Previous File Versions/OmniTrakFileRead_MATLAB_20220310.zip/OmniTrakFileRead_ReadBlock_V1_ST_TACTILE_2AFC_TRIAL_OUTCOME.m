function data = OmniTrakFileRead_ReadBlock_V1_ST_TACTILE_2AFC_TRIAL_OUTCOME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	2720
%		DEFINITION:		ST_TACTILE_2AFC_TRIAL_OUTCOME
%		DESCRIPTION:	SensiTrak tactile discrimination task trial outcome data.

fprintf(1,'Need to finish coding for Block 2720: ST_TACTILE_2AFC_TRIAL_OUTCOME\n');