function data = OmniTrakFileRead_ReadBlock_V1_WINC1500_IP4_ADDR(fid,data)

%	OmniTrak File Block Code (OFBC):
%		151
%		WINC1500_IP4_ADDR

fprintf(1,'Need to finish coding for Block 151: WINC1500_IP4_ADDR');