function data = OmniTrakFileRead_ReadBlock_V1_ZMOD4410_MOX_BOUND(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1700
%		ZMOD4410_MOX_BOUND

fprintf(1,'Need to finish coding for Block 1700: ZMOD4410_MOX_BOUND');