function data = OmniTrakFileRead_ReadBlock_V1_OUTPUT_TRIGGER_NAME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2600
%		OUTPUT_TRIGGER_NAME

fprintf(1,'Need to finish coding for Block 2600: OUTPUT_TRIGGER_NAME');