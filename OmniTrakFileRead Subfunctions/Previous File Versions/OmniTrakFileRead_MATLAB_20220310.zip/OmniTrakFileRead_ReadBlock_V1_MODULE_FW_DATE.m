function data = OmniTrakFileRead_ReadBlock_V1_MODULE_FW_DATE(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	145
%		DEFINITION:		MODULE_FW_DATE
%		DESCRIPTION:	OTMP Module firmware upload date, copied from the macro, written as characters.

fprintf(1,'Need to finish coding for Block 145: MODULE_FW_DATE\n');