function data = OmniTrakFileRead_ReadBlock_V1_STREAM_INPUT_NAME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2100
%		STREAM_INPUT_NAME

fprintf(1,'Need to finish coding for Block 2100: STREAM_INPUT_NAME');