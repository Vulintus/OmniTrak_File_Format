function data = OmniTrakFileRead_ReadBlock_V1_CALIBRATION_BASELINE_ADJUST(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2202
%		CALIBRATION_BASELINE_ADJUST

fprintf(1,'Need to finish coding for Block 2202: CALIBRATION_BASELINE_ADJUST');