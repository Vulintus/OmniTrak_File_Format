function data = OmniTrakFileRead_ReadBlock_V1_HARD_PAUSE_START(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2010
%		HARD_PAUSE_START

fprintf(1,'Need to finish coding for Block 2010: HARD_PAUSE_START');