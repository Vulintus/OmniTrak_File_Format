function data = OmniTrakFileRead_ReadBlock_V1_US_TIMER_ROLLOVER(fid,data)

%	OmniTrak File Block Code (OFBC):
%		24
%		US_TIMER_ROLLOVER

fprintf(1,'Need to finish coding for Block 24: US_TIMER_ROLLOVER');