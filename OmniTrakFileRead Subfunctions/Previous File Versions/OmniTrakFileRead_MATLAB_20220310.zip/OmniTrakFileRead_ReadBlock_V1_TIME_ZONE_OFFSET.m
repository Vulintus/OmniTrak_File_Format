function data = OmniTrakFileRead_ReadBlock_V1_TIME_ZONE_OFFSET(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	25
%		DEFINITION:		TIME_ZONE_OFFSET
%		DESCRIPTION:	Computer clock time zone offset from UTC.

fprintf(1,'Need to finish coding for Block 25: TIME_ZONE_OFFSET\n');