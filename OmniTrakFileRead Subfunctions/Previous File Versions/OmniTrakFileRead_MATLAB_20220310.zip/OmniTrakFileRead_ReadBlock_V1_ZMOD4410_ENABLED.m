function data = OmniTrakFileRead_ReadBlock_V1_ZMOD4410_ENABLED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1009
%		ZMOD4410_ENABLED

fprintf(1,'Need to finish coding for Block 1009: ZMOD4410_ENABLED');