function data = OmniTrakFileRead_ReadBlock_V1_ZMOD4410_IAQ(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1711
%		ZMOD4410_IAQ

fprintf(1,'Need to finish coding for Block 1711: ZMOD4410_IAQ');