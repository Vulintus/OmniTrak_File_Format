function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_PIXELS_INT(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1512
%		MLX90640_PIXELS_INT

fprintf(1,'Need to finish coding for Block 1512: MLX90640_PIXELS_INT');