function data = OmniTrakFileRead_ReadBlock_V1_NTP_SYNC(fid,data)

%	OmniTrak File Block Code (OFBC):
%		20
%		NTP_SYNC

fprintf(1,'Need to finish coding for Block 20: NTP_SYNC');