function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_ADC_RES(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1502
%		MLX90640_ADC_RES

fprintf(1,'Need to finish coding for Block 1502: MLX90640_ADC_RES');