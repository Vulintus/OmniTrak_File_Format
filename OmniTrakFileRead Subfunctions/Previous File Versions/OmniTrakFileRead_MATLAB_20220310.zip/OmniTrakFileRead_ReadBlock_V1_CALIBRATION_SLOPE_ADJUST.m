function data = OmniTrakFileRead_ReadBlock_V1_CALIBRATION_SLOPE_ADJUST(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2203
%		CALIBRATION_SLOPE_ADJUST

fprintf(1,'Need to finish coding for Block 2203: CALIBRATION_SLOPE_ADJUST');