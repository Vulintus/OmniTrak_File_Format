function data = OmniTrakFileRead_ReadBlock_V1_MODULE_CENTER_OFFSET(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	2731
%		DEFINITION:		MODULE_CENTER_OFFSET
%		DESCRIPTION:	Center offset, in millimeters, for the specified OTMP module.

fprintf(1,'Need to finish coding for Block 2731: MODULE_CENTER_OFFSET\n');