function data = OmniTrakFileRead_ReadBlock_V1_RTC_STRING_DEPRECATED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		30
%		RTC_STRING_DEPRECATED

fprintf(1,'Need to finish coding for Block 30: RTC_STRING_DEPRECATED');