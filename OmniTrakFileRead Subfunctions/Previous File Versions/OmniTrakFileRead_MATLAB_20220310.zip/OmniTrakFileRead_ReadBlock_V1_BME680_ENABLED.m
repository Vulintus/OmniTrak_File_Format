function data = OmniTrakFileRead_ReadBlock_V1_BME680_ENABLED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1003
%		BME680_ENABLED

fprintf(1,'Need to finish coding for Block 1003: BME680_ENABLED');