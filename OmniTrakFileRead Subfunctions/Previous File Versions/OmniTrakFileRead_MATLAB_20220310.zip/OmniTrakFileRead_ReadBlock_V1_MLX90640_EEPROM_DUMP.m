function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_EEPROM_DUMP(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1501
%		MLX90640_EEPROM_DUMP

fprintf(1,'Need to finish coding for Block 1501: MLX90640_EEPROM_DUMP');