function data = OmniTrakFileRead_ReadBlock_V1_INIT_THRESH_TYPE(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2320
%		INIT_THRESH_TYPE

fprintf(1,'Need to finish coding for Block 2320: INIT_THRESH_TYPE');