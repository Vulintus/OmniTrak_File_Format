function data = OmniTrakFileRead_ReadBlock_V1_STTC_NUM_PADS(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	2721
%		DEFINITION:		STTC_NUM_PADS
%		DESCRIPTION:	Number of pads on the SensiTrak Tactile Carousel module.

fprintf(1,'Need to finish coding for Block 2721: STTC_NUM_PADS\n');