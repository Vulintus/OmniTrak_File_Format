function data = OmniTrakFileRead_ReadBlock_V1_ZMOD4410_READING_FL(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1703
%		ZMOD4410_READING_FL

fprintf(1,'Need to finish coding for Block 1703: ZMOD4410_READING_FL');