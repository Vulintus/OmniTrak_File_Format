function data = OmniTrakFileRead_ReadBlock_V1_ZMOD4410_ECO2(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1710
%		ZMOD4410_ECO2

fprintf(1,'Need to finish coding for Block 1710: ZMOD4410_ECO2');