function data = OmniTrakFileRead_ReadBlock_V1_MODULE_MICROSTEP(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	2722
%		DEFINITION:		MODULE_MICROSTEP
%		DESCRIPTION:	Microstep setting on the specified OTMP module.

fprintf(1,'Need to finish coding for Block 2722: MODULE_MICROSTEP\n');