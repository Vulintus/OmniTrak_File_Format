function data = OmniTrakFileRead_ReadBlock_V1_CTRL_FW_FILENAME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	141
%		DEFINITION:		CTRL_FW_FILENAME
%		DESCRIPTION:	Controller firmware filename, copied from the macro, written as characters.

fprintf(1,'Need to finish coding for Block 141: CTRL_FW_FILENAME\n');