function data = OmniTrakFileRead_ReadBlock_V1_POSITION_START_XYZ(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2024
%		POSITION_START_XYZ

fprintf(1,'Need to finish coding for Block 2024: POSITION_START_XYZ');