function data = OmniTrakFileRead_ReadBlock_V1_ALSPT19_ENABLED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1007
%		ALSPT19_ENABLED

fprintf(1,'Need to finish coding for Block 1007: ALSPT19_ENABLED');