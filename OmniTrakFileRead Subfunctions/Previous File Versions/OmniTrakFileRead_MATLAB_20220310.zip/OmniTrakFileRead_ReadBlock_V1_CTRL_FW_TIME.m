function data = OmniTrakFileRead_ReadBlock_V1_CTRL_FW_TIME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	143
%		DEFINITION:		CTRL_FW_TIME
%		DESCRIPTION:	Controller firmware upload time, copied from the macro, written as characters.

fprintf(1,'Need to finish coding for Block 143: CTRL_FW_TIME\n');