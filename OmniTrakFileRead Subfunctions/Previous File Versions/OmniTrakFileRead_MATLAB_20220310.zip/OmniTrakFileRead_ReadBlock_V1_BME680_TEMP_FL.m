function data = OmniTrakFileRead_ReadBlock_V1_BME680_TEMP_FL(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1202
%		BME680_TEMP_FL

fprintf(1,'Need to finish coding for Block 1202: BME680_TEMP_FL');