function data = OmniTrakFileRead_ReadBlock_V1_ZMOD4410_R_CDA(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1713
%		ZMOD4410_R_CDA

fprintf(1,'Need to finish coding for Block 1713: ZMOD4410_R_CDA');