function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_I2C_CLOCKRATE(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1504
%		MLX90640_I2C_CLOCKRATE

fprintf(1,'Need to finish coding for Block 1504: MLX90640_I2C_CLOCKRATE');