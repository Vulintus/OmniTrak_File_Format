function data = OmniTrakFileRead_ReadBlock_V1_MS_TIMER_ROLLOVER(fid,data)

%	OmniTrak File Block Code (OFBC):
%		23
%		MS_TIMER_ROLLOVER

fprintf(1,'Need to finish coding for Block 23: MS_TIMER_ROLLOVER');