function data = OmniTrakFileRead_ReadBlock_V1_SGP30_SN(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1400
%		SGP30_SN

fprintf(1,'Need to finish coding for Block 1400: SGP30_SN');