function data = OmniTrakFileRead_ReadBlock_V1_SGP30_ENABLED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1005
%		SGP30_ENABLED

fprintf(1,'Need to finish coding for Block 1005: SGP30_ENABLED');