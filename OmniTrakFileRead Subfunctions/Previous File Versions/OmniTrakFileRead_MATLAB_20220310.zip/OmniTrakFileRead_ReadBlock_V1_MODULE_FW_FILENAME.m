function data = OmniTrakFileRead_ReadBlock_V1_MODULE_FW_FILENAME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	144
%		DEFINITION:		MODULE_FW_FILENAME
%		DESCRIPTION:	OTMP Module firmware filename, copied from the macro, written as characters.

fprintf(1,'Need to finish coding for Block 144: MODULE_FW_FILENAME\n');