function data = OmniTrakFileRead_ReadBlock_V1_AMG8833_THERM_CONV(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1100
%		AMG8833_THERM_CONV

fprintf(1,'Need to finish coding for Block 1100: AMG8833_THERM_CONV');