function data = OmniTrakFileRead_ReadBlock_V1_POSITION_MOVE_XYZ(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2025
%		POSITION_MOVE_XYZ

fprintf(1,'Need to finish coding for Block 2025: POSITION_MOVE_XYZ');