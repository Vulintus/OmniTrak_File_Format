function data = OmniTrakFileRead_ReadBlock_V1_CTRL_FW_DATE(fid,data)

%	OmniTrak File Block Code (OFBC):
%		BLOCK VALUE:	142
%		DEFINITION:		CTRL_FW_DATE
%		DESCRIPTION:	Controller firmware upload date, copied from the macro, written as characters.

fprintf(1,'Need to finish coding for Block 142: CTRL_FW_DATE\n');