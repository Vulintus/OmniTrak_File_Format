function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_REFRESH_RATE(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1503
%		MLX90640_REFRESH_RATE

fprintf(1,'Need to finish coding for Block 1503: MLX90640_REFRESH_RATE');