function data = OmniTrakFileRead_ReadBlock_V1_MLX90640_CALC_TIME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1521
%		MLX90640_CALC_TIME

fprintf(1,'Need to finish coding for Block 1521: MLX90640_CALC_TIME');