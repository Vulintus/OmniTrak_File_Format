function data = OmniTrakFileRead_ReadBlock_V1_ESP8266_IP4_ADDR(fid,data)

%	OmniTrak File Block Code (OFBC):
%		121
%		ESP8266_IP4_ADDR

fprintf(1,'Need to finish coding for Block 121: ESP8266_IP4_ADDR');