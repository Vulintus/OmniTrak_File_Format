function data = OmniTrakFileRead_ReadBlock_V1_SECONDARY_THRESH_NAME(fid,data)

%	OmniTrak File Block Code (OFBC):
%		2310
%		SECONDARY_THRESH_NAME

fprintf(1,'Need to finish coding for Block 2310: SECONDARY_THRESH_NAME');