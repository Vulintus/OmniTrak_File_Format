function data = OmniTrakFileRead_ReadBlock_V1_BME280_ENABLED(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1002
%		BME280_ENABLED

fprintf(1,'Need to finish coding for Block 1002: BME280_ENABLED');