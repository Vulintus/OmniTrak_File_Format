function data = OmniTrakFileRead_ReadBlock_V1_NTP_SYNC_FAIL(fid,data)

%	OmniTrak File Block Code (OFBC):
%		21
%		NTP_SYNC_FAIL

fprintf(1,'Need to finish coding for Block 21: NTP_SYNC_FAIL');