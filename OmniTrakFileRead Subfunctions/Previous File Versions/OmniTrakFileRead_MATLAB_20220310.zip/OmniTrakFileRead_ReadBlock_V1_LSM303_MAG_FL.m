function data = OmniTrakFileRead_ReadBlock_V1_LSM303_MAG_FL(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1803
%		LSM303_MAG_FL

fprintf(1,'Need to finish coding for Block 1803: LSM303_MAG_FL');