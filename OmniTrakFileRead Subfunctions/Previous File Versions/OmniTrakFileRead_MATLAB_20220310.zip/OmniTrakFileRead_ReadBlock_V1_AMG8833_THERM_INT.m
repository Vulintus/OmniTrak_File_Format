function data = OmniTrakFileRead_ReadBlock_V1_AMG8833_THERM_INT(fid,data)

%	OmniTrak File Block Code (OFBC):
%		1102
%		AMG8833_THERM_INT

fprintf(1,'Need to finish coding for Block 1102: AMG8833_THERM_INT');